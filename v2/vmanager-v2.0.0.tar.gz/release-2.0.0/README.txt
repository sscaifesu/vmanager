vmanager v2.0.0 - Proxmox 虚拟机管理工具

## 平台支持

- vmanager-linux-amd64   : Linux x86_64 (Intel/AMD 64位)
- vmanager-linux-arm64   : Linux ARM64 (ARMv8 64位)
- vmanager-linux-arm     : Linux ARM (ARMv7 32位)
- vmanager-macos-arm64   : macOS Apple Silicon (M1/M2/M3)

## 安装方法

1. 下载对应平台的二进制文件
2. 添加执行权限: chmod +x vmanager-*
3. 移动到系统路径: sudo mv vmanager-* /usr/local/bin/vmanager
4. 验证安装: vmanager --version

## 使用示例

# 查看帮助
vmanager --help

# 启动 VM
sudo vmanager start 100

# 批量操作
sudo vmanager stop 100-110

## 校验文件完整性

sha256sum -c SHA256SUMS

## 更多信息

项目主页: https://github.com/sscaifesu/vmanager
文档: https://github.com/sscaifesu/vmanager/blob/main/v2/README.md
许可证: GPL v3.0

作者: YXWA Infosec Lab (Crystal & evalEvil)
